
import pywt
#import matplotlib.pyplot as plt
import numpy as np


import scipy.io as sio
img = sio.loadmat(r'C:\Users\123\Desktop\统计\去噪\深度学习\05\小波前\data.mat')['data']   #im.mat为mat数据的名称，['im'] 中的im表示该文件下im的数据
x = img[ :,:,0]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com1 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,1]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com2 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,2]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com3 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,3]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com4 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,4]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com5 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,5]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com6 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,6]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com7 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,7]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com8 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,8]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com9 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,9]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com10 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,10]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com11 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,11]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com12 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,12]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com13 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,13]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com14 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,14]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com15 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,15]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com16 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,16]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com17 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,17]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com18 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,18]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com19 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,19]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com20 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,20]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com21 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,21]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com22 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一
x = img[ :,:,22]
####小波
yd4_list=[]
yd3_list=[]
yd2_list=[]
yd1_list=[]
ya4_list=[]
for i in range(x.shape[0]): #对每行
    xiaobo_cnl = x[i][:x.shape[1]]  #
    wavelet = 'db4'  # 选取的小波基函数

    wave = pywt.wavedec(xiaobo_cnl, wavelet, level=4)
    # 小波重构
    ya4 = pywt.waverec(np.multiply(wave, [1, 0, 0, 0, 0]).tolist(), wavelet)  # 第4层近似分量
    yd4 = pywt.waverec(np.multiply(wave, [0, 1, 0, 0, 0]).tolist(), wavelet)  # 4-8hz重构小波（θ 节律）
    yd3 = pywt.waverec(np.multiply(wave, [0, 0, 1, 0, 0]).tolist(), wavelet)  # 8-16hz重构小波（α 节律）
    yd2 = pywt.waverec(np.multiply(wave, [0, 0, 0, 1, 0]).tolist(), wavelet)  # 16-32hz重构小波（β 节律）
    yd1 = pywt.waverec(np.multiply(wave, [0, 0, 0, 0, 1]).tolist(), wavelet)  # 32-64hz重构小波（γ 节律）
    yd4_list.append(yd4)
    a= np.array(yd4_list)
    yd3_list.append(yd3)
    b = np.array(yd3_list)
    yd2_list.append(yd2)
    c = np.array(yd2_list)
    yd1_list.append(yd1)
    d = np.array(yd1_list)
    ya4_list.append(ya4)
    e = np.array(ya4_list)
        ##小波包能量
a1_list = []
a2_list = []
a3_list = []
a4_list = []
a5_list = []
for i in range(x.shape[0]):

    b1= pow(np.linalg.norm(a[i][:a.shape[1]], ord=None), 2)
    b2 = pow(np.linalg.norm(b[i][:b.shape[1]], ord=None), 2)
    b3 = pow(np.linalg.norm(c[i][:c.shape[1]], ord=None), 2)
    b4 = pow(np.linalg.norm(d[i][:d.shape[1]], ord=None), 2)
    b5 = pow(np.linalg.norm(e[i][:e.shape[1]], ord=None), 2)
    a1_list.append(b1)
    a1 = np.array(a1_list)
    a2_list.append(b2)
    a2 = np.array(a2_list)
    a3_list.append(b3)
    a3 = np.array(a3_list)
    a4_list.append(b4)
    a4 = np.array(a4_list)
    a5_list.append(b5)
    a5 = np.array(a5_list)

com23 = np.array([a1, a2, a3, a4,a5]) #hebing 5*x.shape[0] 通道一

data=np.array([com1,com2,com3,com4,com5,com6,com7,com8,com9,com10,com11,com12,com13,com14,com15,com16,com17,com18,com19,com20,com21,com22,com23])




import scipy.io as io

mat_path = 'C:/Users/123/Desktop/统计/去噪/深度学习/05/小波后/data.mat'



io.savemat(mat_path, {'name': data})