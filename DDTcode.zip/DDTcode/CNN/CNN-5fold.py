# MLP for Pima Indians Dataset with 10-fold cross validation
from sklearn.model_selection import StratifiedKFold
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Activation, Flatten, Convolution1D, Dropout, MaxPooling1D, BatchNormalization
import numpy as np
import pandas as pd
import scipy.io as sio
import tensorflow as tf
from keras.layers import Input, Dense, Conv2D, MaxPooling2D, Flatten, Dropout, AveragePooling2D,ConvLSTM2D,TimeDistributed
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from sklearn import metrics
from sklearn.model_selection import train_test_split
# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
# load pima indians dataset

z = sio.loadmat(r'C:\Users\123\Desktop\统计\去噪\深度学习\02/小波后/data.mat')['name']
z = np.swapaxes(z, 0, 2)  ##1458 23 4
X = np.swapaxes(z, 1, 2)  ##1458 23 4
a = pd.read_csv(r'C:\Users\123\Desktop\统计\去噪\深度学习\02\小波前/label.csv', delimiter=",", skiprows=0)
Y=a.values
###onehot编码
'''encoder = LabelEncoder()
Y_encoded1 = encoder.fit_transform(Y)
Y1 = np_utils.to_categorical(Y_encoded1)
Y1 = pd.DataFrame(Y1)'''
X_train, X_test, Y_train, Y_test = train_test_split(z, Y, test_size=0.2, random_state=0)
X_train = X_train.reshape(-1, 23, 5,1)
X_test = X_test.reshape(-1, 23, 5,1)
#y_max = Y.idxmax(axis=1)
# define 10-fold cross validation test harness
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
cvscores = []
for train, test in kfold.split(X_train, Y_train):
    # create model
    model = Sequential()
    model.add(Conv2D(16, 3, strides=1, input_shape=(23, 5, 1), activation='relu', padding="same"))
    # kernel_regularizer=regularizers.l2(0.001)))
    model.add(BatchNormalization())
    model.add(MaxPooling2D(2, strides=2, padding='same'))
    model.add(Dropout(0.2))

    model.add(Conv2D(32, 3, strides=1, activation='relu', padding="same"))
    # model.add(Conv2D(32, 3, strides=1, activation='relu', padding="same", kernel_regularizer=regularizers.l2(0.01)))
    model.add(MaxPooling2D(2, strides=2, padding='same'))
    model.add(Flatten())
    model.add(Dropout(0.5))

    model.add(Dense(256, activation='relu'))
    model.add(Dense(60, activation='tanh'))
    model.add(Dense(2, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.SGD(learning_rate=0.01),
                  metrics=['accuracy'])
    # Fit the model
    AA=Y_train[train]
    encoder = LabelEncoder()
    Y_encoded = encoder.fit_transform(AA)
    AA = np_utils.to_categorical(Y_encoded)
    BB=Y_train[test]
    encoder = LabelEncoder()
    Y_encoded = encoder.fit_transform(BB)
    BB = np_utils.to_categorical(Y_encoded)
    model.fit(X_train[train], AA, batch_size=20, epochs=10, verbose=1,validation_data=(X_train[test], BB))
    # evaluate the model
    pred = model.predict(X_test)

    from sklearn.metrics import confusion_matrix

    labe_list = []
    a=len(Y_test)
    for i in range(a):
        if pred[i][0] > pred[i][1]:
           labe_list.append(0)
        else:
            labe_list.append(1)
    pred = np.array(labe_list)
    pred = pred.reshape(a, 1)

    def calculate_metric(gt, pred):

        confusion = confusion_matrix(gt, pred)
        TP = confusion[1, 1]
        TN = confusion[0, 0]
        FP = confusion[0, 1]
        FN = confusion[1, 0]
        print('准确率:', (TP + TN) / float(TP + TN + FP + FN))
        print('灵敏度:', TP / float(TP + FN))  #灵敏度
        print('特异度:', TN / float(TN + FP)) #特异度
        print('FPR:', FP / float(TN + FP))  # 特异度
        print('TP:', TP)
        print('TN:', TN)
        print('FP:', FP)
        print('FN:', FN)

    calculate_metric(Y_test,pred)

    from sklearn.metrics import confusion_matrix,accuracy_score,f1_score,roc_auc_score,recall_score,precision_score
    auc = roc_auc_score(Y_test,pred)
    print('AUC:',auc)
    print('精确率', metrics.precision_score(Y_test, pred))  # 精确率
