
clear;
clc;
load('C:\02\data.mat');
data=zscore(data');
data=data';

for i=1:23
reference(:,i)=[data(1:901,i);data(905:964,i);data(968:1151,i);data(1153:2116,i)];
end

  processSO1 = [];
  count = 1;

  processSO1Row =1;

  slideWindowStart = 0;
  slideWindowEnd = 0;

  step = 10;
  [avgSO1r,avgSO1c] = size(reference);
  for r = 1:avgSO1r 
    slideWindowStart = r;
    slideWindowEnd = slideWindowStart + step - 1;
    if slideWindowEnd == avgSO1r
        for eachStep = slideWindowStart:avgSO1r
            processSO1(processSO1Row,count,1:23) = reference(eachStep,1:23);
            count = count + 1;
        end
        break;
    end
     for eachStep = slideWindowStart:slideWindowEnd
        processSO1(processSO1Row,count,1:23) = data(eachStep,1:23);
        count = count + 1;
     end
   
     processSO1Row = processSO1Row + 1;
     count = 1;
  end

  processSO2 = [];
  count = 1;

  processSO2Row =1;

  slideWindowStart = 0;
  slideWindowEnd = 0;

  step = 10;
  [avgSO2r,avgSO2c] = size(data);
  for r = 1:avgSO2r 
    slideWindowStart = r;
    slideWindowEnd = slideWindowStart + step - 1;
    if slideWindowEnd == avgSO2r
        for eachStep = slideWindowStart:avgSO2r
            processSO2(processSO2Row,count,1:23) = data(eachStep,1:23);
            count = count + 1;
        end
        break;
    end
     for eachStep = slideWindowStart:slideWindowEnd
        processSO2(processSO2Row,count,1:23) = data(eachStep,1:23);
        count = count + 1;
     end
   
     processSO2Row = processSO2Row + 1;
     count = 1;
  end
ppsize=size(processSO2);
psize=size(processSO1);

normal_cdf2=zeros(ppsize(1)-1,9);
procancer_cdf1=zeros(ppsize(1)-1,1);
for j=1:23
for i=2:psize(1)+1
    case1(i-1,1,j)=processSO2(i,10,j);
    re(i-1,1:10,j)=processSO1(i-1,1:10,j);
    mu1=mean(re(i-1,1:10,j));   
    sigma1=std(re(i-1,1:10,j));  
    mu11=mean(case1(i-1,1,j));   
    sigma11=std(case1(i-1,1,j)); 
    procancer_cdf1(i-1,1,j)=normcdf(case1(i-1,1,j),mu1,sigma1);        
    normal_cdf2(i-1,1:10,j)=normcdf(re(i-1,1:10,j),mu1,sigma1);
    normal_cdf2_mean(i-1,1,j)=mean(normal_cdf2(i-1,1:10,j));
    
end
end
a=ppsize(1)-psize(1);
for j=1:23
for i=psize(1)+2:ppsize(1)
    case1(i-1,1,j)=processSO2(i,10,j);
    re(i-1,1:10,j)=processSO1(i-a,1:10,j);
    mu1=mean(re(i-1,1:10,j));   
    sigma1=std(re(i-1,1:10,j));  
    mu11=mean(case1(i-1,1,j));   
    sigma11=std(case1(i-1,1,j)); 
    procancer_cdf1(i-1,1,j)=normcdf(case1(i-1,1,j),mu1,sigma1); %%       
    normal_cdf2(i-1,1:10,j)=normcdf(re(i-1,1:10,j),mu1,sigma1);
    normal_cdf2_mean(i-1,j)=mean(normal_cdf2(i-1,1:10,j));
end
end
P2=squeeze(normal_cdf2_mean);
Q2=squeeze(procancer_cdf1);%%
for j=1:23
for i=1:ppsize(1)-1
    jsd2(i,j)=0.5*(sum(P2(i,j).*log(2.*P2(i,j)./((P2(i,j)+Q2(i,j))))+sum(Q2(i,j).*log(2.*Q2(i,j)./(P2(i,j)+Q2(i,j))))));
end
end
msize=size(jsd2);
jsd_t=mean(jsd2,2);



