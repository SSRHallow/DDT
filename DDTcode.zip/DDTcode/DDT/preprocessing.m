clc
clear

load('C:\02\1.mat');
p01=EEG.data;
for i=1:23
   for j=1:3600  
    profile01(i,j)=mean(p01(i,((j-1)*256+1):(j*256)));
   end
end
clear p01;
%chb07_02
load('C:\02\2.mat');
p02=EEG.data;


for i=1:23
   for j=1:3600
    profile02(i,j)=mean(p02(i,((j-1)*256+1):(j*256)));
   end
end
clear p02;
clear pprofile;
%chb07_02
load('C:\02\3.mat');
p03=EEG.data;


for i=1:23
   for j=1:3600
    profile03(i,j)=mean(p03(i,((j-1)*256+1):(j*256)));
   end
end
clear p03;

%chb07_02
load('C:\02\4.mat');
p04=EEG.data;


for i=1:23
   for j=1:3600
    profile04(i,j)=mean(p04(i,((j-1)*256+1):(j*256)));
   end
end
clear p04;

%chb07_02
load('C:\02\5.mat');
p05=a;


for i=1:23
   for j=1:3600
    profile05(i,j)=mean(p05(i,((j-1)*256+1):(j*256)));
   end
end
clear p05;

%chb07_02
load('C:\02\6.mat');
p06=a;


for i=1:23
   for j=1:3600
    profile06(i,j)=mean(p06(i,((j-1)*256+1):(j*256)));
   end
end
clear p06;
%chb07_02
load('C:\02\7.mat');
p07=a;


for i=1:23
   for j=1:3600
    profile07(i,j)=mean(p07(i,((j-1)*256+1):(j*256)));
   end
end
clear p07;
%chb07_02
load('C:\02\8.mat');
p08=a;


for i=1:23
   for j=1:3600
    profile08(i,j)=mean(p08(i,((j-1)*256+1):(j*256)));
   end
end
clear p08;

%chb07_02
load('C:\02\9.mat');
p09=a;


for i=1:23
   for j=1:3600
    profile09(i,j)=mean(p09(i,((j-1)*256+1):(j*256)));
   end
end
clear p09;
%chb07_02
load('C:\02\10.mat');
p10=a;


for i=1:23
   for j=1:3600
    profile10(i,j)=mean(p10(i,((j-1)*256+1):(j*256)));
   end
end
clear p10;
%chb07_02
load('C:\02\11.mat');
p11=a;


for i=1:23
   for j=1:3600
    profile11(i,j)=mean(p11(i,((j-1)*256+1):(j*256)));
   end
end
clear p11;
%chb07_02
load('C:\02\12.mat');
p12=a;


for i=1:23
   for j=1:3600
    profile12(i,j)=mean(p12(i,((j-1)*256+1):(j*256)));
   end
end
clear p12;
%chb07_02
load('C:\02\13.mat');
p13=a;


for i=1:23
   for j=1:3600
    profile13(i,j)=mean(p13(i,((j-1)*256+1):(j*256)));
   end
end
clear p13;
%chb07_02
load('C:\02\14.mat');
p14=a;


for i=1:23
   for j=1:3600
    profile14(i,j)=mean(p14(i,((j-1)*256+1):(j*256)));
   end
end
clear p14;
%chb07_02
load('C:\02\15.mat');
p15=a;


for i=1:23
   for j=1:3600
    profile15(i,j)=mean(p15(i,((j-1)*256+1):(j*256)));
   end
end
clear p15;
%chb07_02
load('C:\02\16.mat');
p16=a;


for i=1:23
   for j=1:959
    profile16(i,j)=mean(p16(i,((j-1)*256+1):(j*256)));
   end
end
clear p16;
%chb07_02
load('C:\02\16+.mat');
p17=a;


for i=1:23
   for j=1:3600
    profile17(i,j)=mean(p17(i,((j-1)*256+1):(j*256)));
   end
end
clear p17;

%chb07_02
load('C:\02\17.mat');
p18=a;
for i=1:23
   for j=1:3600
    profile18(i,j)=mean(p18(i,((j-1)*256+1):(j*256)));
   end
end
clear p18;

%chb07_02
load('C:\02\18.mat');
p19=a;
for i=1:23
   for j=1:3600
    profile19(i,j)=mean(p19(i,((j-1)*256+1):(j*256)));
   end
end
clear p19;

%chb07_02
load('C:\02\19.mat');
p20=a;
for i=1:23
   for j=1:3600
    profile20(i,j)=mean(p20(i,((j-1)*256+1):(j*256)));
   end
end
clear p20;
load('C:\02\20.mat');
p21=a;
for i=1:23
   for j=1:3600
    profile21(i,j)=mean(p21(i,((j-1)*256+1):(j*256)));
   end
end
clear p21;
load('C:\02\21.mat');
p22=a;
for i=1:23
   for j=1:3600
    profile22(i,j)=mean(p22(i,((j-1)*256+1):(j*256)));
   end
end
clear p22;
load('C:\02\22.mat');
p23=a;
for i=1:23
   for j=1:3600
    profile23(i,j)=mean(p23(i,((j-1)*256+1):(j*256)));
   end
end
clear p23;
load('C:\02\23.mat');
p24=a;
for i=1:23
   for j=1:3600
    profile24(i,j)=mean(p24(i,((j-1)*256+1):(j*256)));
   end
end
clear p24;
load('C:\02\24.mat');
p25=a;
for i=1:23
   for j=1:3600
    profile25(i,j)=mean(p25(i,((j-1)*256+1):(j*256)));
   end
end
clear p25;
load('C:\02\25.mat');
p26=a;
for i=1:23
   for j=1:3600
    profile26(i,j)=mean(p26(i,((j-1)*256+1):(j*256)));
   end
end
clear p26;
load('C:\02\26.mat');
p27=a;
for i=1:23
   for j=1:3600
    profile27(i,j)=mean(p27(i,((j-1)*256+1):(j*256)));
   end
end
clear p27;
load('C:\02\27.mat');
p28=a;
for i=1:23
   for j=1:3600
    profile28(i,j)=mean(p28(i,((j-1)*256+1):(j*256)));
   end
end
clear p28;
load('C:\02\28.mat');
p29=a;
for i=1:23
   for j=1:3600
    profile29(i,j)=mean(p29(i,((j-1)*256+1):(j*256)));
   end
end
clear p29;
load('C:\02\29.mat');
p30=a;
for i=1:23
   for j=1:3600
    profile30(i,j)=mean(p30(i,((j-1)*256+1):(j*256)));
   end
end
clear p30;
load('C:\02\30.mat');
p31=a;
for i=1:23
   for j=1:3600
    profile31(i,j)=mean(p31(i,((j-1)*256+1):(j*256)));
   end
end
clear p31;
load('C:\02\31.mat');
p32=a;
for i=1:23
   for j=1:3600
    profile32(i,j)=mean(p32(i,((j-1)*256+1):(j*256)));
   end
end
clear p32;
load('C:\02\32.mat');
p33=a;
for i=1:23
   for j=1:3600
    profile33(i,j)=mean(p33(i,((j-1)*256+1):(j*256)));
   end
end
clear p33;
load('C:\02\33.mat');
p34=a;
for i=1:23
   for j=1:3600
    profile34(i,j)=mean(p34(i,((j-1)*256+1):(j*256)));
   end
end
clear p34;
load('C:\02\34.mat');
p35=a;
for i=1:23
   for j=1:3600
    profile35(i,j)=mean(p35(i,((j-1)*256+1):(j*256)));
   end
end
clear p35;
load('C:\02\35.mat');
p36=a;
for i=1:23
   for j=1:3600
    profile36(i,j)=mean(p36(i,((j-1)*256+1):(j*256)));
   end
end
clear p36;
%组合
P=[profile01,profile02,profile03,profile04,profile05,profile06,profile07,profile08,profile09,profile10,profile11,profile12,profile13,profile14,profile15,profile16,profile17,profile18,profile19,profile20,profile21,profile22,profile23,profile24,profile25,profile26,profile27,profile28,profile29,profile30,profile31,profile32,profile33,profile34,profile35,profile36];

%对分钟求均值
profile=zscore(P);
for i=1:23
   for j=1:2115
    data1(i,j)=mean(profile(i,((j-1)*60+1):(j*60)));
   end
end
data2=mean(profile(:,126901:126959),2);
data=[data1';data2'];%数据储存在data里面
save 'C:\02\data.mat' data%保存变量data为mat



