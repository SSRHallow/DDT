# 首先,你需要安装和加载 ggplot2 包
install.packages("ggplot2")
library(ggplot2)

# 创建一些示例数据
df <- data.frame(
  group = c("Accuracy", "Sensitivity", "Accuracy", "Sensitivity"),
  category = c("All channels", "All channels", "DNB channels", "DNB channels"),
  value = c(96.77, 50, 98.39, 100)
)
## B图
p <- ggplot(df, aes(fill=group, y=value, x=category)) +
  geom_bar(position="dodge", stat="identity") +
  scale_fill_manual(values=c("#FF4040","#00CDCD")) +
  scale_y_continuous(breaks=seq(45, 100, by=15)) + # 自定义 y 轴刻度
  coord_cartesian(ylim=c(45, 100)) + # 设置 y 轴范围
  geom_text(aes(label=value), position=position_dodge(width=0.9), vjust=-0.25, size=5)+ # 添加数值文本
theme(
  axis.text = element_text(size = 14), # 调整轴文字大小
  legend.text = element_text(size = 14), # 调整图例文字大小
  plot.background = element_rect(fill = "white"), # 整个图表背景
  panel.background = element_rect(fill = "white"), # 图表面板背景
  panel.grid.major = element_blank(), # 移除主要网格线
  panel.grid.minor = element_blank(), # 移除次要网格线
  axis.text.x = element_text(color = "black"), # x轴文字颜色
  axis.text.y = element_text(color = "black"), # y轴文字颜色
  axis.line = element_line(color = "black") # 增加坐标轴线
)
# 打印图表
print(p)



# A图
df <- data.frame(
  group = c("MJSD", "MLP", "STFT+RDANet", "Random forest", "aADGA","SLSTM", "MJSD", "MLP", "STFT+RDANet", "Random forest", "aADGA", "SLSTM"),
  category = c("Accuracy", "Accuracy","Accuracy","Accuracy","Accuracy","Accuracy","Sensitivity","Sensitivity","Sensitivity","Sensitivity","Sensitivity","Sensitivity"),
  value = c(97.78, 93.25, 92.01, 95.87,97.49,94.69,97,88,89.33,95,95.9,95.17)
)
# 指定 group 列的水平顺序
group_levels <- c("MJSD", "MLP", "STFT+RDANet", "Random forest", "aADGA","SLSTM")
df$group <- factor(df$group, levels = group_levels)

p <- ggplot(df, aes(fill=group, y=value, x=category)) +
  geom_bar(position="dodge", stat="identity", width = 0.9) +  # 调整柱子宽度为0.7) 
  scale_fill_manual(values=c("#FF4040","#00CDCD","#1f77b4", "#ff7f0e","#2ca02c","#9467bd")) +
  scale_y_continuous(breaks=seq(45, 100, by=15)) + # 自定义 y 轴刻度
  coord_cartesian(ylim=c(45, 100)) + # 设置 y 轴范围
  geom_text(aes(label=value), position=position_dodge(width=0.9), vjust=-0.25, size=7)+ # 添加数值文本
  theme(
    axis.text = element_text(size = 14), # 调整轴文字大小
    legend.text = element_text(size = 14), # 调整图例文字大小
    plot.background = element_rect(fill = "white"), # 整个图表背景
    panel.background = element_rect(fill = "white"), # 图表面板背景
    panel.grid.major = element_blank(), # 移除主要网格线
    panel.grid.minor = element_blank(), # 移除次要网格线
    axis.text.x = element_text(color = "black"), # x轴文字颜色
    axis.text.y = element_text(color = "black"), # y轴文字颜色
    axis.line = element_line(color = "black") # 增加坐标轴线
  )

# 打印图表
print(p)

# 示例数据
df <- data.frame(
  group = c("This work", "MLP", "STFT+RDANet", "Randomforest", "aADGA", "SLSTM"),
  category = c("Accuracy", "Accuracy", "Accuracy", "Accuracy", "Accuracy", "Accuracy"),
  value = c(98.68, 93.25, 92.01, 95.87, 97.49, 94.69)
)

# 指定group列的水平顺序
group_levels <- c("This work", "MLP", "STFT+RDANet", "Randomforest", "aADGA", "SLSTM")
df$group <- factor(df$group, levels = group_levels)

# 绘图
p <- ggplot(df, aes(fill = group, y = value, x = category)) +
  geom_bar(position = "dodge", stat = "identity", width = 1.1) +
  scale_fill_manual(values = c("#FF4040", "#00CDCD", "#1f77b4", "#ff7f0e", "#2ca02c", "#9467bd")) +
  scale_y_continuous(breaks = seq(45, 100, by = 15)) +
  coord_cartesian(ylim = c(45, 100)) +
  geom_text(aes(label = value), position = position_dodge(width = 1.1), vjust = -0.25, size = 5) +
  theme(
    axis.text = element_text(size = 14),             # 调整轴文字大小
    legend.text = element_text(size = 14),           # 调整图例文字大小
    plot.background = element_rect(fill = "white"),  # 整个图表背景
    panel.background = element_rect(fill = "white"), # 图表面板背景
    panel.grid.major = element_blank(),              # 移除主要网格线
    panel.grid.minor = element_blank(),              # 移除次要网格线
    axis.text.x = element_blank(),                   # 移除x轴文字
    axis.line = element_line(color = "black"),       # 坐标轴线
    axis.title.y = element_text(size = 15)           # 调整y轴标题文字大小
  ) +
  xlab("") +                                        # 移除x轴标签
  ylab("Accuracy")                                  # 设置y轴标签为Accuracy

# 打印图表
print(p)

# 示例数据
df <- data.frame(
  group = c("This work", "MLP", "STFT+RDANet", "Randomforest", "aADGA", "SLSTM"),
  category = c("Sensitivity","Sensitivity","Sensitivity","Sensitivity","Sensitivity","Sensitivity"),
  value = c(98.87,88,89.33,95,95.9,95.17)
)

# 指定group列的水平顺序
group_levels <- c("This work", "MLP", "STFT+RDANet", "Randomforest", "aADGA", "SLSTM")
df$group <- factor(df$group, levels = group_levels)

# 绘图
p <- ggplot(df, aes(fill = group, y = value, x = category)) +
  geom_bar(position = "dodge", stat = "identity", width = 1.1) +
  scale_fill_manual(values = c("#FF4040", "#00CDCD", "#1f77b4", "#ff7f0e", "#2ca02c", "#9467bd")) +
  scale_y_continuous(breaks = seq(45, 100, by = 15)) +
  coord_cartesian(ylim = c(45, 100)) +
  geom_text(aes(label = value), position = position_dodge(width = 1.1), vjust = -0.25, size = 5) +
  theme(
    axis.text = element_text(size = 14),             # 调整轴文字大小
    legend.text = element_text(size = 14),           # 调整图例文字大小
    plot.background = element_rect(fill = "white"),  # 整个图表背景
    panel.background = element_rect(fill = "white"), # 图表面板背景
    panel.grid.major = element_blank(),              # 移除主要网格线
    panel.grid.minor = element_blank(),              # 移除次要网格线
    axis.text.x = element_blank(),                   # 移除x轴文字
    axis.line = element_line(color = "black"),       # 坐标轴线
    axis.title.y = element_text(size = 15)           # 调整y轴标题文字大小
  ) +
  xlab("") +                                        # 移除x轴标签
  ylab("Sensitivity")                                  # 设置y轴标签为Accuracy

# 打印图表
print(p)


# C图
df <- data.frame(
  group = c("Accuracy", "Sensitivity", "Accuracy", "Sensitivity"),
  category = c("Taian Maternity and Child Health Hospital", "Taian Maternity and Child Health Hospital", "West China Hospital", "West China Hospital"),
  value = c(98.38, 100, 97.51, 98)
)

p <- ggplot(df, aes(fill=group, y=value, x=category)) +
  geom_bar(position="dodge", stat="identity") +
  scale_fill_manual(values=c("#FF4040","#00CDCD")) +
  scale_y_continuous(breaks=seq(45, 100, by=15)) + # 自定义 y 轴刻度
  coord_cartesian(ylim=c(45, 100)) + # 设置 y 轴范围
  geom_text(aes(label=value), position=position_dodge(width=0.9), vjust=-0.25, size=5)+ # 添加数值文本
theme(
  axis.text = element_text(size = 12), # 调整轴文字大小
  legend.text = element_text(size = 14), # 调整图例文字大小
  plot.background = element_rect(fill = "white"), # 整个图表背景
  panel.background = element_rect(fill = "white"), # 图表面板背景
  panel.grid.major = element_blank(), # 移除主要网格线
  panel.grid.minor = element_blank(), # 移除次要网格线
  axis.text.x = element_text(color = "black"), # x轴文字颜色
  axis.text.y = element_text(color = "black"), # y轴文字颜色
  axis.line = element_line(color = "black") # 增加坐标轴线
)
# 打印图表
print(p)

# D图
df <- data.frame(
  group = c("Accuracy", "Sensitivity"),
  category = c("Accuracy", "Sensitivity"),
  value = c(98.68, 98.87)
)

p <- ggplot(df, aes(fill=group, y=value, x=category)) +
  geom_bar(position="dodge", stat="identity", width = 0.5) +
  scale_fill_manual(values=c("#FF4040","#00CDCD")) +
  scale_y_continuous(breaks=seq(45, 100, by=15)) + # 自定义 y 轴刻度
  coord_cartesian(ylim=c(45, 100)) + # 设置 y 轴范围
  geom_text(aes(label=value), position=position_dodge(width=0.5), vjust=-0.25, size=5)+ # 添加数值文本
theme(
  axis.text = element_text(size = 13), # 调整轴文字大小
  legend.text = element_text(size = 14), # 调整图例文字大小
  plot.background = element_rect(fill = "white"), # 整个图表背景
  panel.background = element_rect(fill = "white"), # 图表面板背景
  panel.grid.major = element_blank(), # 移除主要网格线
  panel.grid.minor = element_blank(), # 移除次要网格线
  axis.text.x = element_text(color = "black"), # x轴文字颜色
  axis.text.y = element_text(color = "black"), # y轴文字颜色
  axis.line = element_line(color = "black") # 增加坐标轴线
)
# 打印图表
print(p)