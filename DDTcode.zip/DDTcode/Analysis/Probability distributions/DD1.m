
clear;
clc;
qian=xlsread('C:\qian.xlsx');
data=qian(:,10);

minA = min(data);
maxA = max(data);
mu=mean(data);
sigma=std(data);
x=minA:0.0001:maxA;
y=normpdf(x,mu,sigma);

jian=xlsread('C:\jian.xlsx');
data1=jian(150:227,10);

minA1 = min(data1);
maxA1 = max(data1);
mu1=mean(data1);
sigma1=std(data1);
x1=minA:0.0001:maxA;
y1=normpdf(x1,mu1,sigma1);
%% 
fazuo=xlsread('C:\fazuo.xlsx');
data22=mean(fazuo,2);%23pj
data2=[data22(1:3)];
minA2 = min(data2);
maxA2 = max(data2);
mu2=mean(data2);
sigma2=std(data2);
x2=minA2:0.0001:maxA2;
y2=normpdf(x2,mu2,sigma2);
%% ��������
jian=xlsread('C:\jian.xlsx');
data11=mean(jian,2);%23qiuhe
data3=data11(160:230);%0.32
minA1 = min(data3);
maxA1 = max(data3);
mu3=mean(data3);
sigma3=std(data3);
x3=minA:0.0001:maxA;
y3=normpdf(x3,mu3,sigma3);

Alpha=0.05;             
tail='both';              
[h,p1,varci,stats]=vartest2(data,data1,Alpha,tail);
[h,p2,varci,stats]=vartest2(data,data2,Alpha,tail);
[h,p3,varci,stats]=vartest2(data1,data2,Alpha,tail);


figure
plot(x11,y1,'b-','LineWidth',2);
set(gca,'xticklabel',[])
figure
plot(x1,y1,'b-','LineWidth',2);
hold on;
plot(x,y,'r-','LineWidth',2);
hold on;
plot(x2,y2,'g-','LineWidth',2);
hold on;
plot(x3,y3,'y-','LineWidth',2);
legend('Inter','Pre','Ict','Post')



%% �ĸ�ʱ�ںϲ� ��һ��
z=[y1';y';y2';y3';];
z=z';
x11=1:1:965;
figure
plot(x11,z,'b-','LineWidth',2);
set(gca,'xticklabel',[])
%% �ĸ�ʱ�ںϲ� ����һ�� ����һ��
a1=1:1:241;
a=242:1:482;
a2=483:1:724;
a3=725:1:965;
figure
plot(a1,y1,'b-','LineWidth',2);
hold on;
plot(a,y,'r-','LineWidth',2);
hold on;
plot(a2,y2,'g-','LineWidth',2);
hold on;
plot(a3,y3,'y-','LineWidth',2);

set(gca,'xticklabel',[])
